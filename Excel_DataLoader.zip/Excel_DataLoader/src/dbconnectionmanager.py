import pyodbc

class DatabaseConnectionManager:

    def __init__(self, connection_string):
        self.connection_string = connection_string

    def get_connection(self):

        auth = self.connection_string.get("authentication", "sql").lower()

        if auth == "windows":

            conn_str = (
                f"DRIVER={{SQL Server}};"
                f"SERVER={self.connection_string['server']};"
                f"DATABASE={self.connection_string['database']};"
                "Trusted_Connection=yes;"
            )

        else:

            conn_str = (
                f"DRIVER={{SQL Server}};"
                f"SERVER={self.connection_string['server']};"
                f"DATABASE={self.connection_string['database']};"
                f"UID={self.connection_string['user']};"
                f"PWD={self.connection_string['password']};"
            )

        print(f"Connecting to {self.connection_string['server']} / {self.connection_string['database']}")
        print(f"Authentication: {auth}")

        return pyodbc.connect(conn_str)

# import pymssql
# import pyodbc


# class DatabaseConnectionManager:

#     def __init__(self, connection_string):
#         self.connection_string = connection_string

#     def get_connection(self):

#         auth = self.connection_string.get("authentication", "sql").lower()

#         if auth == "windows":

#             return pyodbc.connect(
#                 f"DRIVER={{SQL Server}};"
#                 f"SERVER={self.connection_string['server']};"
#                 f"DATABASE={self.connection_string['database']};"
#                 "Trusted_Connection=yes;"
#             )

#         return pymssql.connect(
#             server=self.connection_string["server"],
#             user=self.connection_string["user"],
#             password=self.connection_string["password"],
#             database=self.connection_string["database"]
#         )
        
