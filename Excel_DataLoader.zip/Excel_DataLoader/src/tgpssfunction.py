import logging
import shutil
# import azure.functions as func
# import pymssql
import pyodbc
import pandas as pd
import json
import os
import uuid
from datetime import datetime
from dbconnectionmanager import DatabaseConnectionManager
# from azure.storage.blob import BlobServiceClient
from io import BytesIO

# Configuration
# Global variable to hold configuration
CONFIG = None

def load_config():
    global CONFIG
    if CONFIG is None:  # Load the config only once
        config_path = os.path.join(os.path.dirname(__file__), 'config.json')
        with open(config_path, 'r') as config_file:
            CONFIG = json.load(config_file)
            logging.info("Configuration loaded successfully.")

def get_environment_mode():
    return CONFIG.get('ENVIRONMENT_MODE')

def get_file_source_mode():
    return CONFIG.get('FILE_SOURCE_MODE')

def get_file_source_path():
    return CONFIG.get('FILE_SOURCE_PATH')

def get_file_source_load():
    return CONFIG.get('FILE_SOURCE_LOAD')

def get_file_source_complete():
    return CONFIG.get('FILE_SOURCE_COMPLETE')

def get_file_source_error():
    return CONFIG.get('FILE_SOURCE_ERROR')

def get_db_connection_string():
    return CONFIG.get('DB_CONNECTION_STRING_' + get_environment_mode())

def get_azure_connection_string():
    return CONFIG.get('AZURE_CONNECTION_STRING_' + get_environment_mode())

def get_azure_container_name():
    return CONFIG.get('CONTAINER_NAME_' + get_environment_mode())

def get_azure_completed_container_name():
    return CONFIG.get('COMPLETE_CONTAINER_NAME_' + get_environment_mode())

def get_azure_error_container_name():
    return CONFIG.get('ERROR_CONTAINER_NAME_' + get_environment_mode())

def get_excel_file_names():
    return CONFIG.get('EXCEL_FILES')

def read_excel_from_blob(mode, container_name=None, blob_name=None, sheet_names=None, local_file_path=None):
    dtype_dict = {
        'MPR': str,
        'Customer Code': str,  # Specify that 'Customer Code' should be read as string
        'Account Number': str,   # Specify that 'Phone Number' should be read as string
        'ACCOUNT_CODE': str,
        'OFFER_ID': str,
        'BILL_ID': str,
        'Query ID': str,
        'Action ID': str,
        'Avg. Billed Value': str,
        'Billed Value': str,
        'Daily Average Bill Value': str,
        'Account Code': str,
        'Transaction Number': str,
        'Amendment Date' : str,
        'File Received Date' : str,
        'Date BR run from' : str,
        'Date BR to' : str,
        'Date BR Sent' : str,
        'Last Billed':str,
        'Last Billed Read Date':str,
        'Date Charged To':str,
        'Start Date':str,
        'Creation Date':str,
        'Contract End Date': str,
        'Instruction Created On': str,
        'Instruction Updated On' : str,
        'Setup DDI Compl Date' :str,
        'DDI Created Date' : str,
        'Current Quote Start Date' :str,
        'Date' : str,
        'Quote Accepted Date':str,
        'Min Sp Confirm Date':str,
        'Max Sp Confirm Date':str,
        'SPN Creation Date':str,
        'CON Creation Date' :str,
        'SPN Exch Rec Type Received' : str,
        '<Header Date>' : str,
        '<Effective>' : str,
        'Unbilled Value' : str,
        'Registration Start Date' : str,
        'MOP Appointment Date' : str,
        'DA Appointment Date' : str,
        'DC Appointment Date' : str,
        'Today''s Date' : str,
        'Read Visit Date' : str,
        'Effective' : str,
        '<ReadDate>' : str,
        'START_DATE' : str,
        'END_DATE' : str,
        'DATE_LAST_BILLED' : str,
        'Print Date' : str,
        'End Date' : str,
        'Read Consumption Date' : str,
        'DATE_CHARGED_TO' : str,
        'DATE (MM/DD/YYYY)': str,
        'Date E-mailed' : str,
        'TransactionDate':str,
        'TransactionPostDate':str,
        'TransactionImportDate':str,
        'DeploymentStartDate':str,
        'DeploymentEndDate':str,
        'HotelArrivalDate':str,
        'HotelDepartureDate':str,
        'GroundTransportationPickupDateTime':str,
        'GroundTransportationDropoffDateTime':str,
        'RailOutboundStartDateTime':str,
        'RailOutboundEndDateTime':str,
        'RailReturnStartDateTime':str,
        'RailReturnEndDateTime':str,
        'DateCreated':str,
        'Issue Time': str
    }

    dtype_dict_dt = {
        'Quote Start Date' :datetime,
        'Quote End Date':datetime,
        'File Received Date' : datetime,
        'Last Billed' :datetime,
        'Date Closed (MM/DD/YYYY)' : datetime,
        'Business Process Date' : datetime,
        'Issue Date':datetime
    }

    loaded_dataframes = {}
    if mode.lower() == "azure":
        blob_service_client = BlobServiceClient.from_connection_string(get_azure_connection_string())
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)

        stream = BytesIO()
        blob_data = blob_client.download_blob()
        blob_data.readinto(stream)
        stream.seek(0)
    elif mode.lower() == "local":

        # local_file_path = folder path
        # file_name = file name passed as parameter

        if not local_file_path:
            raise Exception("local_file_path is required in local mode")

        if not blob_name:
            raise Exception("file_name is required")

        # Combine folder + file
        full_file_path = os.path.join(local_file_path, blob_name)

        # Validate path
        if not os.path.exists(full_file_path):
            raise FileNotFoundError(f"File not found: {full_file_path}")

        if not os.path.isfile(full_file_path):
            raise Exception(f"Path is not a file: {full_file_path}")

        stream = None
        try:
        # Open file
            stream = open(full_file_path, "rb")

        # Use same naming as Azure
            blob_name = blob_name
    
            if blob_name.endswith('.xlsx'):

                all_sheets = pd.read_excel(stream, sheet_name=sheet_names, dtype={'SPID': str})  # Load all sheets into a dictionary

        # Strip spaces from column names after reading
                for sheet_name, df in all_sheets.items():
                    df.columns = df.columns.str.strip()  # Remove leading/trailing spaces from column names
            
            # Loop through the dtype_dict and force conversion to string for each specified column
                    for column in dtype_dict:
                        if column in df.columns:
                            df[column] = df[column].astype(str)

                    for column in dtype_dict_dt:
                        if column in df.columns:
                            df[column] = pd.to_datetime(df[column], errors='coerce')

                for sheet_name in sheet_names:
                    if sheet_name in all_sheets:
                        loaded_dataframes[sheet_name] = all_sheets[sheet_name]
                        print(f"Loaded sheet '{sheet_name}' from '{blob_name}'.")
                    else:
                        print(f"Sheet '{sheet_name}' not found in '{blob_name}', skipping.")
        
                return loaded_dataframes
    
            elif blob_name.endswith('.csv'):
        # If it's a CSV file, read it as a single dataframe
                df = pd.read_csv(stream)

        # Strip spaces from column names
                df.columns = df.columns.str.strip()

        # Loop through the dtype_dict and force conversion to string for each specified column
                for column in dtype_dict:
                    if column in df.columns:
                        df[column] = df[column].astype(str)
        
                for column in dtype_dict_dt:
                    if column in df.columns:
                        df[column] = pd.to_datetime(df[column], errors='coerce')

                print(f"Loaded CSV file '{blob_name}'.")

                return {blob_name: df}
        finally:
            if stream:
                stream.close()
    else:
        raise Exception("Invalid mode. Use 'azure' or 'local'")


# Read excel file from blob
def read_excel_from_blob1(container_name, blob_name, sheet_names):
    """Read an Excel file directly from Azure Blob Storage into a DataFrame."""
    blob_service_client = BlobServiceClient.from_connection_string(get_azure_connection_string())
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    
    # Download the blob content as bytes
    # blob_data = blob_client.download_blob().readall()
    
    # Use BytesIO to read the Excel file into a pandas DataFrame
    # with BytesIO(blob_data) as stream:
    #     # Reading all sheets from the Excel file
    #     return pd.read_excel(stream, sheet_name=sheet_name)
    
    # Download the blob as a stream
    stream = BytesIO()
    blob_data = blob_client.download_blob()
    blob_data.readinto(stream)

    # Move to the beginning of the stream
    stream.seek(0)

    # Define the columns and their respective data types in the dtype dictionary
    dtype_dict = {
        'MPR': str,
        'Customer Code': str,  # Specify that 'Customer Code' should be read as string
        'Account Number': str,   # Specify that 'Phone Number' should be read as string
        'ACCOUNT_CODE': str,
        'OFFER_ID': str,
        'BILL_ID': str,
        'Query ID': str,
        'Action ID': str,
        'Avg. Billed Value': str,
        'Billed Value': str,
        'Daily Average Bill Value': str,
        'Account Code': str,
        'Transaction Number': str,
        'Amendment Date' : str,
        'File Received Date' : str,
        'Date BR run from' : str,
        'Date BR to' : str,
        'Date BR Sent' : str,
        'Last Billed':str,
        'Last Billed Read Date':str,
        'Date Charged To':str,
        'Start Date':str,
        'Creation Date':str,
        'Contract End Date': str,
        'Instruction Created On': str,
        'Instruction Updated On' : str,
        'Setup DDI Compl Date' :str,
        'DDI Created Date' : str,
        'Current Quote Start Date' :str,
        'Date' : str,
        'Quote Accepted Date':str,
        'Min Sp Confirm Date':str,
        'Max Sp Confirm Date':str,
        'SPN Creation Date':str,
        'CON Creation Date' :str,
        'SPN Exch Rec Type Received' : str,
        '<Header Date>' : str,
        '<Effective>' : str,
        'Unbilled Value' : str,
        'Registration Start Date' : str,
        'MOP Appointment Date' : str,
        'DA Appointment Date' : str,
        'DC Appointment Date' : str,
        'Today''s Date' : str,
        'Read Visit Date' : str,
        'Effective' : str,
        '<ReadDate>' : str,
        'START_DATE' : str,
        'END_DATE' : str,
        'DATE_LAST_BILLED' : str,
        'Print Date' : str,
        'End Date' : str,
        'Read Consumption Date' : str,
        'DATE_CHARGED_TO' : str,
        'Issue Time': str
    }

    dtype_dict_dt = {
        'Quote Start Date' :datetime,
        'Quote End Date':datetime,
        'File Received Date' : datetime,
        'Last Billed' :datetime
    }

    # Read all sheets from the Excel file
    # all_sheets = pd.read_excel(stream, sheet_name=None, dtype=dtype_dict)  # Load all sheets into a dictionary
    loaded_dataframes = {}

    if blob_name.endswith('.xlsx'):

        all_sheets = pd.read_excel(stream, sheet_name=sheet_names, dtype={'SPID': str})  # Load all sheets into a dictionary

        # Strip spaces from column names after reading
        for sheet_name, df in all_sheets.items():
            df.columns = df.columns.str.strip()  # Remove leading/trailing spaces from column names
            
            # Loop through the dtype_dict and force conversion to string for each specified column
            for column in dtype_dict:
                if column in df.columns:  # Check if the column exists in the dataframe
                    df[column] = df[column].astype(str)  # Convert the column to string explicitly

            for column in dtype_dict_dt:
                if column in df.columns:  # Check if the column exists in the dataframe
                    df[column] = pd.to_datetime(df[column], errors='coerce')  # errors='coerce': This ensures that if a value can't be converted to a valid datetime, it will be replaced with NaT (Not a Time), rather than raising an error. You can change this to 'raise' if you want to throw an error when invalid datetime formats are encountered.

        for sheet_name in sheet_names:
            if sheet_name in all_sheets:
                loaded_dataframes[sheet_name] = all_sheets[sheet_name]
                print(f"Loaded sheet '{sheet_name}' from '{blob_name}'.")
            else:
                print(f"Sheet '{sheet_name}' not found in '{blob_name}', skipping.")
        
        return loaded_dataframes  # Return the dictionary of loaded DataFrames
    
    elif blob_name.endswith('.csv'):
        # If it's a CSV file, read it as a single dataframe
        df = pd.read_csv(stream)

        # Strip spaces from column names
        df.columns = df.columns.str.strip()

        # Loop through the dtype_dict and force conversion to string for each specified column
        for column in dtype_dict:
            if column in df.columns:
                df[column] = df[column].astype(str)
        
        for column in dtype_dict_dt:
                if column in df.columns:  # Check if the column exists in the dataframe
                    df[column] = pd.to_datetime(df[column], errors='coerce')  # errors='coerce': This ensures that if a value can't be converted to a valid datetime, it will be replaced with NaT (Not a Time), rather than raising an error. You can change this to 'raise' if you want to throw an error when invalid datetime formats are encountered.

        print(f"Loaded CSV file '{blob_name}'.")

        return {blob_name: df}

def blob_movement(blob_name, mode, file_mode):

    if file_mode == "azure":
        try :
            
            # Initialize the BlobServiceClient using your connection string
            blob_service_client = BlobServiceClient.from_connection_string(get_azure_connection_string())

            # Specify the source and destination container and blob names
            source_container_name = get_azure_container_name()
            destination_container_name = get_azure_completed_container_name() if mode == 1 else get_azure_error_container_name()

            # Get the source and destination containers
            source_container_client = blob_service_client.get_container_client(source_container_name)
            destination_container_client = blob_service_client.get_container_client(destination_container_name)

            # Get the source blob client
            source_blob_client = source_container_client.get_blob_client(blob_name)

            # Get the destination blob client (in the new container)
            destination_blob_client = destination_container_client.get_blob_client(blob_name)

            MAX_BLOB_NAME_LENGTH = 1024

            # Ensure the blob name is within the allowed length
            if len(blob_name) > MAX_BLOB_NAME_LENGTH:
                blob_name = blob_name[:MAX_BLOB_NAME_LENGTH]

            # Now proceed with copying the blob
            destination_blob_client = destination_container_client.get_blob_client(blob_name)
            copy_blob = destination_blob_client.start_copy_from_url(source_blob_client.url)

            # Optionally, wait until the copy is complete (check if the copy is successful)
            copy_status = copy_blob['copy_status']
            if copy_status == 'success':
                print(f"Blob copied successfully to {destination_container_name}/{blob_name}")
                
                # Now delete the original blob (optional, if you want to "move" instead of "copy")
                source_blob_client.delete_blob()
                print(f"Original blob deleted from {source_container_name}/{blob_name}")
            else:
                print(f"Error occurred during copy: {copy_status}")
        
        except Exception as e:
            print(f"Blob movement error : {e}")
            # Catch any exceptions
            error_message = f"blob_movement, Blob Name : {blob_name}, error : {str(e)}"
            logging.error(error_message)  # Log the error to a file
            log_message_to_db(None, error_message)  # Log to the database as well
    else :
        try:
            # Read config
            base_path = get_file_source_path()
            to_load = get_file_source_load()
            complete = get_file_source_complete()
            error = get_file_source_error()

            # Source (To_Load)
            source_folder = os.path.join(base_path, to_load)

            # Destination
            destination_folder = os.path.join(
                base_path,
                complete if mode == 1 else error
            )

            # Ensure destination folder exists
            if not os.path.exists(destination_folder):
                os.makedirs(destination_folder)

            source_file = os.path.join(source_folder, blob_name)
            destination_file = os.path.join(destination_folder, blob_name)

            if not os.path.exists(source_file):
                raise FileNotFoundError(f"File not found: {source_file}")

            if not os.path.isfile(source_file):
                raise Exception(f"Not a valid file: {source_file}")

            # If file already exists in destination → overwrite
            if os.path.exists(destination_file):
                os.remove(destination_file)

            # Move file
            shutil.move(source_file, destination_file)
            print(f"File moved successfully to: {destination_folder}")

        except Exception as e:
            print(f"Local file movement error: {e}")

            error_message = f"local_file_movement, File: {blob_name}, error: {str(e)}"
            logging.error(error_message)
            log_message_to_db(None, error_message)


# Configuration for database connection
# SQL_SERVER_CONNECTION_STRING = {
#     'server': 'malkom-dev-all-mssql-45315c391c7a.c1rarf2edpl8.us-west-2.rds.amazonaws.com',
#     'user': 'admin',
#     'password': '0f184d631295',
#     'database': 'TGP_ClientDB_Dev'
# }

# load loaded excel file from blob into database
def insert_into_database(dataframes, table_name, column_mapping, newfileinsertedkey, mode=2):
    try:
        data_dump_successfull = True
        db_manager = DatabaseConnectionManager(get_db_connection_string())
        connection = db_manager.get_connection()
        connection.autocommit = False
        cursor = connection.cursor()

        try:
            # Use a transaction
            valid_columns = []

            # Rename DataFrame columns and validate data types
            for column_name, column_info in column_mapping.items():
                db_column_name = column_info['db_column_name']
                data_type = column_info['data_type']

                # Rename the DataFrame column
                dataframes.columns = dataframes.columns.str.strip()
                dataframes.rename(columns={column_name: db_column_name}, inplace=True)
                valid_columns.append(db_column_name)

                # Validate the data type (example checks)
                if data_type == "INT":
                    if not pd.api.types.is_integer_dtype(dataframes[db_column_name]):
                        raise ValueError(f"Column '{db_column_name}' must be of integer type.")

                elif data_type == "FLOAT":
                    if not pd.api.types.is_float_dtype(dataframes[db_column_name]):
                        raise ValueError(f"Column '{db_column_name}' must be of float type.")

                elif data_type == "DATE":
                    if not pd.api.types.is_datetime64_any_dtype(dataframes[db_column_name]):
                        raise ValueError(f"Column '{db_column_name}' must be of date type.")

            # Filter out columns that are not in the valid_columns list
            dataframes = dataframes[valid_columns]

            # Add new columns for the unique key and file reference
            dataframes[table_name.replace("_TBL", "") + '_KEY'] = [uuid.uuid4() for _ in range(len(dataframes))]
            dataframes['FILE_LOAD_REF'] = newfileinsertedkey

            # Indivual row insertion code _____________________________________________________________________________________________
            if mode == 1:

                # Insert each row of the DataFrame into the table
                for index, row in dataframes.iterrows():

                    values = []
                    for col in valid_columns:
                        value = row[col]
                        if pd.isna(value) or value == '' or value == 'nan':  # Check for NaN or blank values
                            values.append(None)  # Replace with None (SQL NULL)
                        else:
                            values.append(value)

                    # Add additional values for the other columns
                    values.append(newfileinsertedkey)
                    values.append(row[table_name.replace("_TBL", "") + '_KEY'])


                    # Define the SQL INSERT query with placeholders (?)
                    insert_query = f"""
                    INSERT INTO {table_name} ({', '.join(valid_columns + ['FILE_LOAD_REF', table_name.replace("_TBL", "") + '_KEY'])})
                    VALUES ({', '.join(['?'] * len(valid_columns) + ['?', '?'])})
                    """

                    try:
                        # Execute the insert query with the processed values
                        cursor.execute(insert_query, tuple(values))
                        connection.commit()  # Commit the transaction after each row
                        print(f"Row {index} inserted successfully.")
                        print(f"Data inserted into table '{table_name}'.")

                    except Exception as e:
                        print(f"Error inserting row {index}: {e}")
                        connection.rollback()  # Rollback if an error occurs

            # bulk row insertion code _____________________________________________________________________________________________
            elif mode == 2 :
                
                try:
                    valid_columns_with_keys = valid_columns + ['FILE_LOAD_REF', table_name.replace("_TBL", "") + '_KEY']

                    # Ensure NaN values are handled as NULL in SQL
                    # dataframes = dataframes.where(pd.notnull(dataframes), None)
                    dataframes = dataframes.map(lambda x: None if pd.isna(x) or x == '' else x)

                    # Create the list of tuples for bulk insert
                    insert_data = []

                    for index, row in dataframes.iterrows():
                        # Prepare each row by adding the FILE_LOAD_REF and the unique key
                        # row_values = list(row[valid_columns]) + [newfileinsertedkey, row[table_name.replace("_TBL", "") + '_KEY']]
                        
                        values = []
                        for col in valid_columns:
                            value = row[col]
                            if pd.isna(value) or value == '' or value == 'nan':  # Check for NaN or blank values
                                values.append(None)  # Replace with None (SQL NULL)
                            else:
                                values.append(value)

                        # Add additional values for the other columns
                        values.append(newfileinsertedkey)
                        values.append(row[table_name.replace("_TBL", "") + '_KEY'])
                        
                        insert_data.append(tuple(values))

                    # Construct the SQL insert query
                    insert_query = f"""
                    INSERT INTO {table_name} ({', '.join(valid_columns_with_keys)})
                    VALUES ({', '.join(['?'] * len(valid_columns_with_keys))})
                    """

                    try:
                        # Perform the bulk insert using executemany
                        cursor.executemany(insert_query, insert_data)
                        connection.commit()  # Commit the transaction after all rows are inserted
                        print(f"Bulk insert into {table_name} completed successfully.")
                        log_message_to_db(newfileinsertedkey, f"Bulk insert into {table_name} completed successfully.")  # Log to the database as well

                    except pyodbc.Error as e:
                        # Handle any SQL-related exceptions
                        data_dump_successfull = False
                        error_message = f"insert_file_info, Error executing stored procedure, Table Name : {table_name}, error : {str(e)}"
                        logging.exception(error_message)
                        log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well
                        connection.rollback()  # Rollback in case of error

                    except Exception as e:
                        # Catch any other exceptions
                        data_dump_successfull = False
                        error_message = f"insert_file_info, Error executing stored procedure, Table Name : {table_name}, error : {str(e)}"
                        logging.exception(error_message)  # Log the error to a file
                        log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well
                        connection.rollback()  # Rollback if any error occurs
                    
                except Exception as e:
                    # Catch any other exceptions
                    data_dump_successfull = False
                    error_message = f"insert_into_database, Error preparing sql query, Table Name : {table_name}, error : {str(e)}"
                    logging.error(error_message)  # Log the error to a file
                    log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well

        except Exception as e:
            # Catch any other exceptions
            data_dump_successfull = False
            error_message = f"insert_into_database, Error validating columns, Table Name : {table_name}, error : {str(e)}"
            logging.error(error_message)  # Log the error to a file
            log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well

        
    except pyodbc.OperationalError as e:
        # Handle specific DB connection error
        data_dump_successfull = False
        error_message = f"insert_file_info, Database connection error : {str(e)}"
        logging.error(error_message)  # Log the error to a file
        log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well

    except pyodbc.Error as e:
        # Handle any SQL-related exceptions
        data_dump_successfull = False
        error_message = f"insert_file_info, Error executing stored procedure, Table Name : {table_name}, error : {str(e)}"
        logging.exception(error_message)
        log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well
        connection.rollback()  # Rollback in case of error
    
    except Exception as e:
        # Catch any other exceptions
        data_dump_successfull = False
        error_message = f"insert_file_info, Error executing stored procedure, Table Name : {table_name}, error : {str(e)}"
        logging.exception(error_message)  # Log the error to a file
        log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well

    finally:
        # Ensure the cursor and connection are closed properly
        try:
            if cursor:
                cursor.close()
        except:
            pass

        try:
            if connection:
                connection.close()
        except:
            pass
    return data_dump_successfull
         
def  get_existing_key(filename):
    db_manager = DatabaseConnectionManager(get_db_connection_string())
    connection = db_manager.get_connection()
    connection.autocommit = False
    cursor = connection.cursor()

    query = f"""select file_load_key from TBL_FILE_LOAD where UPPER(FILE_NAME) = UPPER('{filename}') and UPPER(status) = UPPER('Pending') and FILE_DATA_SOURCE = 'SPREADSHEET' """
    cursor.execute(query)
    result = cursor.fetchone()[0]
    return result

def insert_file_info(filedetails, newfileinsertedkey, status, mode):
    
    # Establish a connection using pymssql
    # Use pymssql.connect with the connection parameters (host, user, password, database)
    # connection = pymssql.connect(
    #     host=get_db_connection_string()['host'],
    #     user=get_db_connection_string()['user'],
    #     password=get_db_connection_string()['password'],
    #     database=get_db_connection_string()['database']
    # )
    # logging.info('Successfully connected to the database.')

    try:
        latest_key = None        
        # Attempt to connect to the database
        # db_manager = DatabaseConnectionManager(SQL_SERVER_CONNECTION_STRING)
        db_manager = DatabaseConnectionManager(get_db_connection_string())
        connection = db_manager.get_connection()
        connection.autocommit = False
        cursor = connection.cursor()

        if filedetails != None and 'filename' in filedetails:
            newfileinsertedkey = get_existing_key(filedetails['filename'])

        if mode == 1:
           
            # Define the stored procedure name for mode 1
            stored_procedure_name = 'SP_INSERT_UPDATE_TGP_FILE_DETAILS' 

            # Parameters
            fileloadref = newfileinsertedkey
            filedatasource = filedetails['filedatasource']
            filename = filedetails['filename']
            recordcount = filedetails['recordcount']
            status = status

            # Step 1: Execute the stored procedure for mode 1
            cursor.execute(
                f"EXEC {stored_procedure_name} ?, ?, ?, ?, ?, ?",
                (
                    fileloadref,
                    "SPREADSHEET",  # Example of static parameter
                    filename,
                    recordcount,
                    status,
                    mode
                )
            )

            # Commit the transaction (optional, depending on whether the procedure itself commits or not)
            connection.commit()
            logging.info(f"Stored procedure {stored_procedure_name} executed successfully.")

            # Step 2: Retrieve the latest inserted key
            stored_procedure_name = 'SP_GET_LATEST_FILE_LOAD_KEY'
            cursor.execute(
                f"EXEC {stored_procedure_name} ?",
                (filename,)
            )

            # Fetch the result of the stored procedure
            latest_key_row = cursor.fetchone()

            if latest_key_row:
                latest_key = latest_key_row[0]  # Assuming the first column is the key
                print(f"Newly added key: {latest_key}")
                connection.commit()  # Commit the changes
                return latest_key
            else:
                print("No row returned")
                return None
        elif mode == 2:
            # Define the stored procedure name for mode 2
            stored_procedure_name = 'SP_INSERT_UPDATE_TGP_FILE_DETAILS'

            # Parameters for mode 2
            fileloadref = newfileinsertedkey
            filedatasource = None
            filename = None
            recordcount = None 
            status = status

            # Step 3: Execute the stored procedure for mode 2
            cursor.execute(
                f"EXEC {stored_procedure_name} ?, ?, ?, ?, ?, ?",
                (
                    str(fileloadref),
                    filedatasource,
                    filename,
                    recordcount,
                    status,
                    mode
                )
            )

            # Commit the transaction
            connection.commit()
            print(f"Record update: {fileloadref}")
            latest_key = fileloadref
            return latest_key
        else:
            logging.error(f"Invalid mode value: {mode}")
            return None
            

    except pyodbc.OperationalError as e:
        # Handle specific DB connection error
        error_message = f"insert_file_info, Database connection error : {str(e)}"
        logging.error(error_message)  # Log the error to a file
        log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well

    except pyodbc.Error as e:
        # Handle any SQL-related exceptions
        connection.rollback()  # Rollback in case of error
        error_message = f"insert_file_info, Error executing stored procedure, File Name : {filename}, error : {str(e)}"
        logging.exception(error_message)
        log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well
        
    
    except Exception as e:
        # Catch any other exceptions
        connection.rollback()  # Rollback in case of error
        error_message = f"insert_file_info, Error executing stored procedure, File Name : {filename}, error : {str(e)}"
        logging.exception(error_message)  # Log the error to a file
        log_message_to_db(newfileinsertedkey, error_message)  # Log to the database as well

    finally:
        # Ensure the cursor and connection are closed properly
        try:
            if cursor:
                cursor.close()
        except:
            pass

        try:
            if connection:
                connection.close()
        except:
            pass
    return latest_key

def update_file_status(file_load_ley,status):
    try:
        db_manager = DatabaseConnectionManager(get_db_connection_string())
        connection = db_manager.get_connection()
        connection.autocommit = False
        cursor = connection.cursor()
        
        update_query = """
            UPDATE TBL_FILE_LOAD SET status = 'ERROR' WHERE status = ? and file_load_key = ?
        """
        cursor.execute(update_query, (status,file_load_ley))
        connection.commit()

    except pyodbc.OperationalError as e:
        # Handle specific DB connection error
        error_message = f"log_message_to_db, Database connection error : {str(e)}"
        logging.error(error_message)  # Log the error to a file

    except pyodbc.Error as e:
        # Handle any SQL-related exceptions
        error_message = f"log_message_to_db, Error executing sql query, error : {str(e)}"
        logging.error(error_message)

    finally:
        try:
            if cursor:
                cursor.close()
        except:
            pass

        try:
            if connection:
                connection.close()
        except:
            pass


def log_message_to_db(file_load_ley, message):
    try:
        db_manager = DatabaseConnectionManager(get_db_connection_string())
        connection = db_manager.get_connection()
        connection.autocommit = False
        cursor = connection.cursor()
        
        insert_query = """
            INSERT INTO TBL_FILE_PROCESSING_LOG (FILE_PROCESSING_LOG_KEY, TEXT, CREATED_DATE, FILE_LOAD_REF) 
            VALUES (?, ?, ?, ?)
        """
        cursor.execute(insert_query, (str(uuid.uuid4()), message, datetime.now(), file_load_ley))
        connection.commit()

        if file_load_ley != None and message != None and 'ERROR' in message.upper() :
            update_file_status(file_load_ley,'Pending')
    
    except pyodbc.OperationalError as e:
        # Handle specific DB connection error
        error_message = f"log_message_to_db, Database connection error : {str(e)}"
        logging.error(error_message)  # Log the error to a file

    except pyodbc.Error as e:
        # Handle any SQL-related exceptions
        error_message = f"log_message_to_db, Error executing sql query, error : {str(e)}"
        logging.error(error_message)

    except Exception as e:
        # Log to file if DB logging fails
        error_message = f"log_message_to_db, error : {str(e)}"
        logging.error(error_message)  # Log the error to a file

    finally:
        try:
            if cursor:
                cursor.close()
        except:
            pass

        try:
            if connection:
                connection.close()
        except:
            pass

def check_azfunction_running_status(mode=0):
    try:
        instance_execution_status = True
        fndbstatus = 0
        db_manager = DatabaseConnectionManager(get_db_connection_string())
        connection = db_manager.get_connection()
        connection.autocommit = False
        cursor = connection.cursor()

        if mode == 1:
            cursor.execute("SELECT TOP 1 PARAMETER from [GLOBAL_CONFIGURATION] WHERE TITLE = 'AZ_FUNCTION_RUNNING_STATUS'")
            result = cursor.fetchone()
            fndbstatus = int(result[0])
            logging.info(f"check_azfunction_running_status result: {fndbstatus}")

            if fndbstatus == 1:
                instance_execution_status = False
                logging.info(f"Azure function is already running, skiping this instance")
            elif fndbstatus == 0:
                instance_execution_status = True
                logging.info(f"Azure function is not running, executing this instance")
                update_query = """ UPDATE GLOBAL_CONFIGURATION SET PARAMETER = 1 WHERE TITLE = 'AZ_FUNCTION_RUNNING_STATUS'"""
                cursor.execute(update_query)
                connection.commit()
            else:
                instance_execution_status = False
        elif mode == 2:
            instance_execution_status = True
            logging.info(f"Azure function parameter updating")
            update_query = """ UPDATE GLOBAL_CONFIGURATION SET PARAMETER = 0 WHERE TITLE = 'AZ_FUNCTION_RUNNING_STATUS'"""
            cursor.execute(update_query)
            connection.commit()

    except pyodbc.OperationalError as e:
        # Handle specific DB connection error
        instance_execution_status = False
        error_message = f"check_azfunction_running_status, Mode : {mode},  Database connection error : {str(e)}"
        logging.error(error_message)  # Log the error to a file

    except pyodbc.Error as e:
        # Handle any SQL-related exceptions
        instance_execution_status = False
        error_message = f"check_azfunction_running_status, Mode : {mode}, Error executing sql query, error : {str(e)}"
        logging.error(error_message)

    except Exception as e:
        # Log to file if DB logging fails
        instance_execution_status = False
        error_message = f"check_azfunction_running_status, Mode : {mode}, error : {str(e)}"
        logging.error(error_message)  # Log the error to a file

    finally:
        try:
            if cursor:
                cursor.close()
        except:
            pass

        try:
            if connection:
                connection.close()
        except:
            pass
    return instance_execution_status

def main():

        configloaded = True
        blobloaded = True
        fileloadDB = True
        sheetdataloadDB = True
        fileupdateDB = True
        blobmovement = True
        try:
            # Load config file into global variable
            load_config()

            instance_execution_status = check_azfunction_running_status(1)

            log_message_to_db(None,"Data Loader started")

        except Exception as e:
            configloaded = False
            print (f"Error while loading config data: {e}")


        if configloaded & instance_execution_status:
            # Iterate each file name with available in EXCEL_FILES.file_name
            for blob_name in get_excel_file_names():
                try:
                    
                    blobloaded = True
                    
                    file_name = blob_name['file_name']
                    sheet_names = blob_name['sheet_names']
                    table_name = blob_name['table_name']
                    column_mapping = blob_name['columns']

                    file_name = file_name.replace("{Date}", datetime.today().strftime("%d%m%Y"))

                    try:
                        # Read Excel file directly from Azure Blob Storage
                        # dataframes = read_excel_from_blob(get_azure_container_name(), file_name,sheet_names)
                        dataframes = read_excel_from_blob(get_file_source_mode(),get_azure_container_name(), file_name,sheet_names,os.path.join(get_file_source_path(),get_file_source_load()))
                    except Exception as e:
                        blobloaded = False
                        # log_message_to_db(None,f"read_excel_from_blob, File Name : {file_name}, Reason : {str(e)}")
                        print(f"Error reading {file_name} from blob : {e}")

                    if blobloaded:
                        #get key from db using file details
                        newfileinsertedkey = None
                        if file_name != None :
                            newfileinsertedkey = get_existing_key(file_name)
                       
                        # Insert each DataFrame into the database
                        for sheet_names, df in dataframes.items():
                            try :
                                
                                fileloadDB = True
                                sheetdataloadDB = True
                                fileupdateDB = True
                                blobmovement = True

                                filedetails = {}
                                filedetails["filedatasource"] = file_name
                                filedetails["filename"] = file_name
                                filedetails["recordcount"] = df.shape[0]
                                
                                try :
                                    #insert file related info first time with loading status
                                    newfileinsertedkey = insert_file_info(filedetails,None,"LOADING",1)
                                    if newfileinsertedkey is None:
                                        fileloadDB = False
                                except Exception as e:
                                    fileloadDB = False
                                    log_message_to_db(newfileinsertedkey,f"insert_file_info, File Name : {file_name}, Reason : {str(e)}")

                                if fileloadDB:
                                    try :
                                        #insert blob sheet data from dataframe (df)into database
                                        data_dump = insert_into_database(df, table_name, column_mapping, newfileinsertedkey,2)
                                        if not data_dump:
                                            sheetdataloadDB = False
                                    except Exception as e:
                                        sheetdataloadDB = False
                                        print (f"Error while inserting sheet data into DB {file_name}: {e}")
                                
                                if fileloadDB & sheetdataloadDB:
                                    try :
                                        #update file related info with completed status
                                        newfileinsertedkey = insert_file_info(None,newfileinsertedkey,"COMPLETED",2)
                                        if newfileinsertedkey is None:
                                            try :
                                                blob_movement(file_name,2,get_file_source_mode())
                                            except Exception as e:
                                                print(f"Blob movement success : {e}")
                                        else:
                                            try :
                                                blob_movement(file_name,1,get_file_source_mode())
                                            except Exception as e:
                                                print(f"Blob movement success : {e}") 
                                    except Exception as e:
                                        try :
                                            blob_movement(file_name,2,get_file_source_mode())
                                        except Exception as e:
                                            print(f"Blob movement success : {e}")
                                        log_message_to_db(newfileinsertedkey,f"update_file_info - completed, File Name : {file_name}, Reason : {str(e)}")
                                else:
                                    try :
                                        #update file related info with completed status
                                        newfileinsertedkey = insert_file_info(None,newfileinsertedkey,"ERROR",2)
                                        try :
                                            blob_movement(file_name,2,get_file_source_mode())
                                        except Exception as e:
                                            print(f"Blob movement success : {e}")
                                    except Exception as e:
                                        try :
                                            blob_movement(file_name,2,get_file_source_mode())
                                        except Exception as e:
                                            print(f"Blob movement success : {e}")
                                        log_message_to_db(newfileinsertedkey,f"update_file_info - error, File Name : {file_name}, Reason : {str(e)}")
                                    
                                    
                            except Exception as e:
                                print (f"Error processing {file_name}: {e}")
                                try :
                                    blob_movement(file_name,2,get_file_source_mode())
                                except Exception as e:
                                    print(f"Blob movement error : {e}")
                                log_message_to_db(newfileinsertedkey,f"Error processing {file_name} from blob, File Name : {file_name}, Reason : {str(e)}")

                except Exception as e:
                    print(f"Error processing {file_name} from blob : {e}")
                    try :
                        blob_movement(file_name,2,get_file_source_mode())
                    except Exception as e:
                        print(f"Blob movement error : {e}")
                    log_message_to_db(newfileinsertedkey,f"Error processing {file_name} from blob, File Name : {file_name}, Reason : {str(e)}")

            check_azfunction_running_status(2)
            
        log_message_to_db(None,"Data Loader Completed")   
        
def setup_logger():
    base_log_dir = "logs"

    if not os.path.exists(base_log_dir):
        os.makedirs(base_log_dir)
    today = datetime.now().strftime("%Y-%m-%d")
    daily_dir = os.path.join(base_log_dir, today)
    if not os.path.exists(daily_dir):
        os.makedirs(daily_dir)
    instance_id = str(uuid.uuid4())[:8]
    log_file = os.path.join(daily_dir, f"data_loader_{instance_id}.log")
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    if logger.hasHandlers():
        logger.handlers.clear()
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(message)s"
    )
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return log_file
if __name__ == "__main__":
    main()